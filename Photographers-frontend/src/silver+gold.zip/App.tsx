import { useState } from 'react'
import './App.css'
import AppRouter from './router';
import Charts from './tests/Charts';


function App() {
  const [_count, _setCount] = useState(0)

  return (
    <>
       <AppRouter />
       <Charts />
    </>
  )
}

export default App
