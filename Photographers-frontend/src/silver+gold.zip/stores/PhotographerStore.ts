import { create } from 'zustand';
import PhotographerList from '../service/PhotographersApi';
import Photographer from '../model/Photographer';

// Define and export the store state and actions
export interface PhotographerStoreState {
    opened: boolean;
    photographers: Photographer[];
    selectedPhotographer: Photographer | null;
    handleOpen: (p?: Photographer) => void;
    handleClose: () => void;
    addPhotographer: (p: Photographer) => void;
    editPhotographer: (p: Photographer) => void;
    deletePhotographer: (pId: number) => void;
}

// Zustand store for managing photographers
const usePhotographerStore = create<PhotographerStoreState>((set) => ({
    opened: false,
    selectedPhotographer: null,
    photographers: PhotographerList,

    handleOpen: (p?: Photographer) => set({ opened: true, selectedPhotographer: p || null }),

    handleClose: () => set({ opened: false, selectedPhotographer: null }),

    addPhotographer: (p: Photographer) =>
        set((state) => ({
            photographers: [...state.photographers, p],
        })),

    editPhotographer: (p: Photographer) =>
        set((state) => ({
            photographers: state.photographers.map((photog) =>
                photog.id === p.id ? p : photog
            ),
            selectedPhotographer: state.selectedPhotographer?.id === p.id ? p : state.selectedPhotographer,
        })),

    deletePhotographer: (pId: number) =>
        set((state) => ({
            photographers: state.photographers.filter((photog) => photog.id !== pId),
            selectedPhotographer: state.selectedPhotographer?.id === pId ? null : state.selectedPhotographer,
        })),
}));

export default usePhotographerStore;
