import { Grid, Typography } from '@mui/material';
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import Photographer from '../model/Photographer';
import PhotographersList from '../service/PhotographersApi';
import '../styles/TextFieldStyle.css';

import usePhotographerStore from '../stores/PhotographerStore';

const Detail = () => {
    const params = useParams();
    const [p, setPhotographer] = useState<Photographer | undefined>(undefined);

    const { photographers } = usePhotographerStore();
    React.useEffect(() => {
        if (params.id) {
            setPhotographer(
                PhotographersList.find((p) => p.id === parseInt(params.id!)),
            );
            setPhotographer(photographers.find((p) => p.id === parseInt(params.id!)));
        }
    }, [params.id]);

    if (!p) {
        return <Typography variant="h4" color="whitesmoke">Photographer not found</Typography>;
    }

    return (
        <>
            <Grid container spacing={4} sx={{ padding: 4 }}>
                {/* Left Side: Photo */}
                <Grid item xs={12} md={6}>
                    <img
                        src={p.profilepicUrl}
                        alt={p.name}
                        style={{ width: '100%', height: 'auto', borderRadius: '8px' }}
                    />
                </Grid>

                {/* Right Side: Details */}
                <Grid item xs={12} md={6}>
                    <Grid container spacing={2}>
                        {/* Name */}
                        <Grid item xs={12}>
                            <Typography variant="h3" color="black">
                                {p.name}
                            </Typography>
                        </Grid>

                        {/* Birth Date - Death Date */}
                        <Grid item xs={12}>
                            <Typography variant="h5" color="black">
                                {`Born: ${p.birth.toLocaleDateString()}`}
                            </Typography>
                            {p.death && (
                                <Typography variant="h5" color="black">
                                    {`Died: ${p.death.toLocaleDateString()}`}
                                </Typography>
                            )}
                        </Grid>

                        {/* Description */}
                        <Grid item xs={12}>
                            <Typography variant="body1" color="black" sx={{ marginTop: 2 }}>
                                {p.description}
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </>
    );
};

export default Detail;